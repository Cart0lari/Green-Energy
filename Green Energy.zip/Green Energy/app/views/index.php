<?php
// Incluir arquivo de conexão com o banco de dados
include("../config/conexaoBD.php");

session_start(); // Inicia a sessão para verificar o login

// Verifica se o usuário está logado
$usuarioLogado = isset($_SESSION['usuario']) ? $_SESSION['usuario'] : null;

// Redireciona para o login se não estiver logado
if (!isset($_SESSION['usuario'])) {
    header("Location: ./login/login.php");
    exit();
}

// Verifica se o usuário é administrador ou um usuário regular
if ($_SESSION['usuario'] === 'Administrador') {
    $usuarioNome = 'Administrador';
    $paginaAdm = '<a href="./admin/pagina_adm.php">Página Administrador</a>';
} else {
    $usuarioNome = $usuarioLogado;
    $paginaAdm = "";
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistemas Inteligentes de Armazenamento de Energia</title>
    <link rel="stylesheet" href="../public/css/login_index_style.css">
    <style>
        .saiba_mais{
            display: flex;
            color: #ffff;  /* Cor do texto branco */
            font-size: 1rem;width: auto; /* O botão vai ter o tamanho de acordo com o conteúdo (neste caso o texto "Saiba mais") */
            max-width: 300px; /* Limita a largura máxima do botão (300px) */
            display: inline-block; /* Faz o botão ter um comportamento mais flexível, sem ocupar toda a largura */
            text-align: center; /* Alinha o texto no centro do botão */
            text-align: center;
            padding: 10px 20px;  /* Adicionando padding aos links */
            border-radius: 20px;  /* Bordas arredondadas para os links */
            background-color: #003b00;  /* Fundo do botão de Notícias */
        }

        .texto_verde{
            color: #003b00;
        }

        .centralizando{
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <header class="header">
            <img src="../public/imagens/logo.png" alt="Logo" class="logo">
            <div class="nav-links">
                <div class="nav-links-left">
                    <p class="centralizando">
                        <span class="texto_verde">Bem-vindo, <?php echo $usuarioLogado; ?></span>
                    </p>   
                </div>   
                <div class="nav-links-right">
                    <?php echo $paginaAdm; ?>
                    <a href="./login/logout.php">Logout</a>
                    <a href="./contato/contato.php">Contato</a>
                </div>
            </div>
        </header>
        
        <br><h1 class="main-title">Sistemas Inteligentes De Armazenamento De Energia</h1>

        <section class="content">
            <div class="video">
                <video class="rounded-video" autoplay muted loop width="440" height="500">
                    <source src="../public/videos/video.mp4" type="video/mp4">
                    Seu navegador não suporta a tag de vídeo.
                </video>
            </div>

            <div class="text">
                <br><h2 class="centralizando">O Futuro da Sustentabilidade</h2><br>
                <p>O armazenamento inteligente de energia permite capturar e gerenciar a energia de forma eficiente, especialmente a proveniente de fontes renováveis como solar e eólica. Essa tecnologia otimiza o uso da energia, reduzindo custos e promovendo uma abordagem mais sustentável para o futuro energético.</p><br>

                <p>Os sistemas inteligentes de armazenamento de energia estão emergindo como uma das soluções mais promissoras para enfrentar os desafios do futuro energético sustentável. Essa tecnologia permite a captura e o gerenciamento eficiente de energia, especialmente de fontes renováveis, como solar e eólica, que são intermitentes por natureza. Ao integrar sistemas avançados de controle e armazenamento, esses sistemas não só melhoram a eficiência energética, mas também possibilitam a redução de custos, a otimização do consumo e a estabilização da rede elétrica. Com o crescimento da demanda por fontes de energia limpa, os sistemas de armazenamento inteligente desempenham um papel crucial na promoção de uma matriz energética mais sustentável e resiliente.</p>
            </div>
        </section>

        <br><br><h1 class="main-title">Artigos</h1>
        <section class="articles">
            <p><b>Baterias Blade da BYD: Segurança e Inovação no Futuro dos Veículos Elétricos </b> </p><br>
            <p>Com a crescente popularidade dos veículos elétricos (VEs), a segurança das baterias se tornou uma das questões mais cruciais para os fabricantes e consumidores. As baterias são o coração dos carros elétricos, e garantir que elas sejam seguras, duráveis e eficientes é essencial para o avanço do setor de mobilidade elétrica. Nesse contexto, a BYD, uma das líderes globais no desenvolvimento de soluções de mobilidade elétrica e energia renovável, apresentou uma inovação que promete mudar os padrões de segurança no mercado: as Baterias Blade...</p> <br>
                <div class="saiba_mais">
                    <a href="./login/artigo_1.php">saiba mais</a>
                </div>
                <br><br><br>

            <p><b>Estradas para Carregar Veículos Elétricos em Movimento: O Futuro da Mobilidade Sustentável</b></p><br>
            <p>Com o crescente número de veículos elétricos (VEs) nas ruas, a questão da infraestrutura de recarga tornou-se um dos maiores desafios para o futuro da mobilidade elétrica. Embora o número de postos de recarga esteja crescendo, a necessidade de tornar os carregamentos mais rápidos, eficientes e convenientes é cada vez mais urgente. Uma solução inovadora que está sendo explorada para resolver este problema são as estradas inteligentes, ou estradas dinâmicas, projetadas para carregar veículos elétricos enquanto eles estão em movimento...  </p><br>
            <div class="saiba_mais">
                <a href="./login/artigo_2.php">saiba mais</a> 
            </div>
            <br><br><br>

            <p><b>O Que é o Sistema de Rolo Suíço ou Micro-Origami? Descubra Como a Ciência Está Criando Estruturas Microscópicas Incríveis! </b></p><br>
            <p>Já imaginou um material que, ao sofrer um pequeno "deslizar", se enrola sozinho em uma forma cilíndrica minúscula? Essa incrível capacidade de transformação está no coração de uma inovação científica chamada sistema de rolo suíço, ou micro-origami. Embora o nome "origami" nos remeta ao ato de dobrar papel, no caso do micro-origami, a ideia é muito mais sobre como camadas finas de materiais podem se enrolar em escalas microscópicas, criando estruturas de tamanho tão pequeno que podem ser comparadas ao tamanho de um grão de sal...  </p> <br>
            <div class="saiba_mais">
                <a href="./login/artigo_3.php">saiba mais</a>
            </div><br><br><br>

            <p><b>Venda de Energia Solar no Brasil: Como Funciona e Oportunidades para Consumidores e Produtores </b></p><br>
            <p>Com o crescente interesse por fontes de energia renováveis, a energia solar se destaca como uma das alternativas mais viáveis e sustentáveis para a geração de eletricidade. Além de reduzir a dependência de fontes de energia não renováveis, como os combustíveis fósseis, a energia solar também oferece oportunidades econômicas para consumidores e empresas. Muitos se perguntam: é possível vender energia solar? A resposta é sim!... </p><br>
            <div class="saiba_mais">
                <a href="./login/artigo_4.php">saiba mais</a>
            </div><br><br><br>

            <p><b>Armazenamento Gravitacional de Energia: Uma Solução Promissora para o Futuro da Energia Sustentável!</b> </p><br>
            <p>À medida que o mundo se volta para fontes de energia renovável, como solar e eólica, a necessidade de soluções eficazes para o armazenamento de energia se torna cada vez mais urgente...</p> <br>
                <div class="saiba_mais">
                    <a href="./login/artigo_5.php">saiba mais</a>
                </div>
                <br><br><br>

        </section>
    </div>

    <div class="footer"> <!--Divisao de espaço para o rodapé-->
        <p class="footer-content"> © 2024 Loja X. Todos os direitos reservados.</p> <!--Linha de paragrafo para o rodapé-->
        <p class="footer-content"> Politica de Privacidade | Termos de Serviço</p>
        <p class="footer-content">
            Siga-nos: <a href="https://www.facebook.com/senaisp.pirituba/" class="social-link">Facebook</a> 
            <a href="https://www.instagram.com/senai.sp/" class="social-link">Instagram</a>
            <a href="https://x.com/i/flow/login?redirect_after_login=%2FSENAIPirituba" class="social-link">Twitter</a>
            <a href="https://br.linkedin.com/company/senai-pirituba" class="social-link">LinkedIn</a>
        </p>
    </div>
    
</body>
</html>
