-- Criando a tabela Cadastro (já existe conforme o seu código)
DROP DATABASE IF EXISTS formulario;
CREATE DATABASE formulario;
USE formulario;

CREATE TABLE Cadastro (
    IdCadastro INT AUTO_INCREMENT PRIMARY KEY,
    Nome VARCHAR(50),
    Email VARCHAR(100) UNIQUE,
    Senha VARCHAR(50),
    Datanascimento DATE,
    Telefone VARCHAR(14),
    CPF VARCHAR(11),
    Endereco VARCHAR(100),
    comentario TEXT,
    status ENUM('ativo', 'bloqueado') DEFAULT 'ativo' -- Define "ativo" como valor padrão
);

-- Inserindo dados na tabela Cadastro
INSERT INTO Cadastro (Email, Senha, status)
VALUES ('administrador@senaisp.edu.br', 'admsenaimahfuz', 'ativo');

-- Criando a tabela Comentarios
CREATE TABLE Comentarios (
    IdComentario INT AUTO_INCREMENT PRIMARY KEY,
    IdCadastro INT,  -- Chave estrangeira para vincular o comentário ao cadastro
    comentario TEXT,
    data TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (IdCadastro) REFERENCES Cadastro(IdCadastro) ON DELETE CASCADE
);

-- Criando a tabela CalculosBateria para armazenar os cálculos
CREATE TABLE CalculosBateria (
    IdCalculo INT AUTO_INCREMENT PRIMARY KEY,
    IdCadastro INT,  -- Chave estrangeira para vincular o cálculo ao cadastro
    PercentualInicial FLOAT,  -- Percentual inicial da bateria
    KmsNecessarios FLOAT,  -- Quantidade de quilômetros necessários para completar a carga
    DataCalculo TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  -- Data e hora do cálculo
    FOREIGN KEY (IdCadastro) REFERENCES Cadastro(IdCadastro) ON DELETE CASCADE
);

-- Inserindo um exemplo de cálculo (isso será feito pelo código PHP automaticamente)
-- INSERT INTO CalculosBateria (IdCadastro, PercentualInicial, KmsNecessarios) 
-- VALUES (1, 30, 17.5);
