<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$cadastro = isset($_SESSION['cadastro']) ? $_SESSION['cadastro'] : null;
unset($_SESSION['cadastro']); // Limpa a mensagem após exibir

$erroMensagem = isset($_SESSION['erroLogin']) ? $_SESSION['erroLogin'] : null;
unset($_SESSION['erroLogin']); // Limpa a mensagem após exibir
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela de Login</title>
    <link rel="stylesheet" href="../../public/css/login_style.css">
</head>
<body>
    <div>
        <h1>Login</h1>
        <form method="POST" action="../../controllers/controlador_login.php">
            <input type="text" name="email" placeholder="E-mail">
            <br><br>
            <input type="password" name="senha" placeholder="Senha">
            <br><br>

            <button type="submit" name="action" value="login">Login</button>
            <br><br>
            <button type="submit" name="action" value="formulario">Cadastrar</button>
            <br><br>
            
            <button type="submit" name="action" value="voltar">Voltar</button>
            <br>
        </form>
        <?php if (!empty($cadastro)): ?>
            <p style="color: green; text-align: center;"><?= $erroMensagem ?></p>
        <?php endif; ?>
        <?php if (!empty($erroMensagem)): ?>
            <p style="color: red; text-align: center;"><?= $erroMensagem ?></p>
        <?php endif; ?>
    </div>
</body>
</html>
