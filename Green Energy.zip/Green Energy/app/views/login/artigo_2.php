<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistemas Inteligentes de Armazenamento de Energia</title>
    <!-- <link rel="stylesheet" href="styles_baterias_blade.css"> -->
    <link rel="stylesheet" href="../../public/css/styles_artigos.css">
    <style>
        .centralizando {
            text-align: center;
            align-items: center;
            align-self: center;
        }

        .comentario_artigo {
            margin: 20px;
        }

        .comentario_artigo form {
            margin-bottom: 20px;
        }

        .comentario_artigo textarea {
            align-items: center;
            width: 85%;
            height: 150px;
            padding: 10px 10px 10px;
            margin-bottom: 10px;
            border: 1px solid #000000;
            border-radius: 5px;
        }

        .comentario_artigo button {
            background-color: #006400;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .comentario_artigo button:hover {
            background-color: #0056b3;  
        }

        .comentario {
            text-align: center;
            height: auto;
            width: center;
            margin-bottom: 10px;
            border: 1px solid #888;
            padding: 10px 1px 15px;
            border-radius: 5px;
        }

        .comentario strong {
            text-align: center;
            display: block;
            font-weight: bold;
        }

        .comentario i {
            text-align: center;
            font-size: 0.9em;
            color: #888;
        }
        
        .botao_calculo{
            text-decoration: none;
            color: #fff;  /* Cor do texto branco */
            font-size: 1rem;
            padding: 10px 20px;  /* Adicionando padding aos links */
            border-radius: 20px;  /* Bordas arredondadas para os links */
            transition: background-color 0.3s ease;
            background-color: #004d00;
        }

    </style>
</head>
<body>

<?php 

    session_start(); // Inicia a sessão para verificar o login
    
    $usuarioLogado = isset($_SESSION['usuario']) ? $_SESSION['usuario'] : null;
    
    // Redireciona para o login se não estiver logado
    if (!isset($_SESSION['usuario'])) {
        header("Location: ./login.php");
        exit();
    }
    
    if ($_SESSION['usuario'] === 'Administrador') {
        $usuarioNome = 'Administrador';
        $paginaAdm = '<a href="./admin/pagina_adm.php">Página Administrador</a>';
    } else {
        $usuarioNome = $usuarioLogado;
        $paginaAdm = "";
    }
?>
    <div class="container">
        <header class="header">
            <img src="../../public/imagens/logo.png" alt="Logo" class="logo">
            <div class="nav-links">
                <p class="centralizando"><span class="texto_verde">Bem-vindo, <?php echo $usuarioLogado; ?></span></p>
                <div class="nav-links-right">
                    <a href="./logout.php">Logout</a>
                    <a href="../contato/contato.php">Contato</a>                  
                    <a href="../index.php" class="back-button">Voltar</a>
                </div>
            </div>
        </header>

        <br><h1 class="main-title">Estradas para Carregar Veículos Elétricos em Movimento: O Futuro da Mobilidade Sustentável</h1>

        <section class="content">
            <div class="video-container">
                <video class="rounded-video" autoplay muted loop width="440" height="250">
                    <source src="../../public/videos/carregamento_via_inducao.mp4" type="video/mp4">
                    Seu navegador não suporta a tag de vídeo.
                </video>
            </div>

            <div class="text">
                <h2 class="centralizando">Introdução</h2>
                <p>Com o crescente número de <b>veículos elétricos (VEs)</b> nas ruas, a questão da <b>infraestrutura de recarga</b> tornou-se um dos maiores desafios para o futuro da mobilidade elétrica. Embora o número de postos de recarga esteja crescendo, a necessidade de tornar os carregamentos mais rápidos, eficientes e convenientes é cada vez mais urgente. Uma solução inovadora que está sendo explorada para resolver este problema são as <b>estradas inteligentes</b>, ou <b>estradas dinâmicas</b>, projetadas para carregar veículos elétricos enquanto eles estão em movimento. </p> <br>
        </section>
        
        <div class="text2">
            <h2>Como Funcionam as Estradas para Carregar Veículos Elétricos em Movimento? </h2>
            <img src="../../public/imagens/carregamento.jpg" alt="">

            <p>As <b>estradas dinâmicas</b> são projetadas para transmitir energia de forma contínua para os veículos elétricos, sem que estes precisem parar para uma carga completa. Existem duas abordagens principais para a implementação dessa tecnologia</p><br>
            
            <h3 style="color:#006400;">Carregamento Indutivo (Sem Fio)</h3><br>

            <p>O carregamento indutivo é uma tecnologia que utiliza campos magnéticos para transferir energia elétrica sem a necessidade de conexões físicas diretas. Ao longo da estrada, são instaladas bobinas que geram um campo magnético de alta frequência. Quando um veículo elétrico equipado com uma bobina receptora passa por essa área, a energia é transferida para a bateria do carro através do campo magnético, carregando o veículo enquanto ele está em movimento.<br>
            Essa tecnologia é similar ao carregamento sem fio utilizado em smartphones, mas em uma escala muito maior. Ela permite que os carros se carreguem de forma contínua enquanto estão circulando pelas vias, o que resolve o problema da autonomia limitada dos veículos elétricos. 
            Quer saber quantos kms seu carro elétrico teria que andar em uma estrada dessa para carregar completamente? <br>
            <a class="botao_calculo" href="../processo/processo.php">Calcule</a>
           
          </p><br>

            <h3 style="color:#006400;">Infraestrutura de Recarga sem Paradas</h3><br>
            <p>Com a recarga sendo feita enquanto o veículo está em movimento, os motoristas não precisarão parar em postos de recarga durante a viagem. Isso não só melhora a <b>conveniência</b> e <b>eficiência</b> da condução, mas também ajuda a reduzir a sobrecarga de infraestruturas de recarga em áreas urbanas e rodovias movimentadas. </p><br>

            <h3 style="color:#006400;">Redução de Custo com Infraestrutura de Recarga</h3><br>
            <p>A construção de estações de recarga pode ser cara e lenta, especialmente em áreas remotas. Com o <b>carregamento contínuo nas estradas</b>, a necessidade de uma rede massiva de estações de recarga pode ser significativamente reduzida, tornando a transição para veículos elétricos mais acessível e menos onerosa. </p>

            
            <h3 style="color:#006400;">Potencial de Redução das Emissões de Carbono</h3><br>
            <p>Com a implementação de <b>estradas para carregar veículos elétricos</b>, pode-se aumentar ainda mais a adoção de carros elétricos, reduzindo a dependência de veículos a combustão. Isso contribuiria para uma <b>redução significativa de emissões de gases de efeito estufa</b>, ajudando a combater as mudanças climáticas.</p>

        </div><br>

        <div class="text2">
            <h2>Desafios e Considerações Técnicas</h2>
            <img src="../../public/imagens/carregamento_inducao.jpg" alt="">
            <br><h3 style="color:#006400;">Custo de Implementação</h3><br>
            <p>A construção de estradas dinâmicas envolve um alto custo inicial, especialmente no que diz respeito à instalação de sistemas de carregamento indutivo ou de fiação embutida. A infraestrutura necessária para transformar as rodovias em "estradas inteligentes" exigirá investimento significativo por parte de governos e empresas.</p>

            <h3 style="color:#006400;">Segurança e Durabilidade</h3><br>
            <p>A instalação de bobinas ou cabos sob a estrada pode ser desafiadora em termos de <b>segurança</b> e <b>durabilidade</b>. O desgaste das estradas devido ao tráfego intenso e condições climáticas extremas pode afetar a eficiência e segurança do sistema de carregamento. </p>

            <h3 style="color:#006400;">Padronização e Compatibilidade</h3><br>
            <p>A padronização da tecnologia é um fator importante para garantir a <b>compatibilidade entre diferentes modelos de veículos</b> e as infraestruturas de carregamento. Isso exigiria um esforço global para garantir que as tecnologias de carregamento sejam compatíveis com uma ampla gama de veículos elétricos.</p>

            <h3 style="color:#006400;">Questões Regulatórias e de Privacidade</h3>
            <p>O monitoramento constante da quantidade de energia fornecida e o rastreamento de veículos em tempo real podem levantar questões relacionadas à privacidade e regulamentação. Os governos precisariam definir normas claras para garantir que essas tecnologias sejam usadas de forma ética e eficiente.</p>
        </div>
        <br>
        <div class="text2">
            <h2>Exemplos de Projetos em Desenvolvimento </h2>
            <img src="../../public/imagens/electric-road.jpg" alt="">

            <p>Vários projetos estão sendo desenvolvidos ao redor do mundo para testar e implementar as estradas dinâmicas para carregamento de veículos elétricos. <br>
            Sistemas de carregamento indutivo na Suécia: O país está testando um sistema de carregamento dinâmico em uma estrada entre Gotemburgo e o aeroporto de Landvetter. O projeto eRoadArlanda utiliza tecnologia indutiva para carregar ônibus elétricos enquanto circulam.<br>
            Energy from the Road (Reino Unido): A empresa OLEV (On-Road Electric Vehicle) está desenvolvendo uma tecnologia que usa bobinas magnéticas embutidas nas estradas para carregar veículos elétricos em movimento.<br> 
            Energy Vault: Embora este projeto esteja mais focado em armazenar energia através de sistemas gravitacionais, ele compartilha a ideia de fornecer soluções de recarga de energia sustentável em grande escala. </p>
        </div>

        <div class="text2">
            <h2>Conclusão: O Futuro da Mobilidade Sustentável</h2>
            <img src="../../public/imagens/carregamento-rua-detroid.jpg" alt="">
            
            <p>As <b>estradas para carregar veículos elétricos em movimento</b> são um exemplo impressionante de como a tecnologia pode transformar o futuro da mobilidade. Ao permitir que veículos elétricos recarreguem suas baterias enquanto circulam, essa tecnologia pode resolver um dos maiores obstáculos da mobilidade elétrica — a autonomia limitada. <br>
            Embora haja desafios técnicos e financeiros a serem superados, o conceito de <b>estradas dinâmicas</b> representa um passo importante para um futuro mais sustentável, onde veículos elétricos possam se tornar a norma e o transporte sustentável seja acessível a todos. À medida que mais testes e inovações acontecem, é possível que, em breve, vejamos esse futuro se tornando realidade. 
            </p>
        </div>
            <br>
            <p class="centralizando"><a class="botao_calculo" href="https://www.bbc.com/portuguese/articles/c72g098dj9vo">Fonte do contéudo</a>
            <br>
           </p>
        </div>
    </div>

            <!-- Conteúdo do Artigo (omitido para brevidade) -->
    <section class="comentario_artigo">
        <div class="centralizando">
            <h2 class="text2">Deixe seu comentário</h2>
            <br>
            <!-- Formulário de Comentário -->
            <form method="POST" action="../../controllers/controlador_comentarios.php">
                <textarea name="comentario" placeholder="Digite seu comentário aqui"></textarea><br>
                <button type="submit" name="botao_comentario">Enviar Comentário</button>
            </form>

            <!-- Mensagem de Sucesso ou Erro -->
            <p class="centralizando"><?php echo isset($_GET['comentarioEnviado']) ? $_GET['comentarioEnviado'] : ''; ?></p>
            <p class="centralizando" style="color: red;"><?php echo isset($_GET['erroMensagem']) ? $_GET['erroMensagem'] : ''; ?></p>

            <h3>Comentários</h3>
             <?php
                // Incluir o arquivo de conexão com o banco de dados
                include("../../config/conexaoBD.php");

                // Buscar todos os comentários com nome e data
                $sql = "SELECT Cadastro.Nome, Comentarios.comentario, Comentarios.data 
                        FROM Comentarios 
                        INNER JOIN Cadastro ON Comentarios.IdCadastro = Cadastro.IdCadastro 
                        ORDER BY Comentarios.data DESC";

                $result = $conexao->query($sql);

                // Exibir os comentários
                if ($result && $result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="comentario">';
                            echo '<strong>' . htmlspecialchars($row['Nome']) . '</strong>';
                            echo '<p>' . htmlspecialchars($row['comentario']) . '</p>';
                            echo '<p><i>' . date('d/m/Y H:i', strtotime($row['data'])) . '</i></p>';
                        echo '</div>';
                    }
                } else {
                    echo '<p>Nenhum comentário encontrado.</p>';
                }
                ?>
            </div>
        </section>
</body>
</html>
