<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8"> <!-- Define a codificação de caracteres para o documento -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Garante que o layout seja responsivo em dispositivos móveis -->
        <title>Tela de Contato</title> <!-- Título da página exibido na aba do navegador -->
        <link rel="stylesheet" href="../../public/css/contato_style.css"> 
    </head>

    <body>
        <div class="contact-cards-container">
            <!-- Cartão Redes Sociais -->
            <div class="contact-card">
                <h3>Redes Sociais</h3> <!-- Título do cartão de redes sociais -->
                <p>Nos siga nas nossas redes sociais:</p> <!-- Descrição sobre as redes sociais -->
                <div class="social-links">
                    <!-- Links para as redes sociais -->
                    <a href="https://www.facebook.com/senaisp.pirituba/" target="_blank" class="social-link facebook">Facebook</a>
                    <a href="https://br.linkedin.com/company/senai-pirituba" target="_blank" class="social-link linkedin">LinkedIn</a>
                    <a href="https://www.instagram.com/senai.sp/" target="_blank" class="social-link instagram">Instagram</a>
                    <a href="https://x.com/i/flow/login?redirect_after_login=%2FSENAIPirituba" target="_blank" class="social-link twitter">Twitter</a>
                </div>
            </div>

            <!-- Cartão E-mail -->
            <div class="contact-card">
                <h3>Entre em Contato por E-mail</h3> <!-- Título do cartão de e-mail -->
                <p>Envie-nos uma mensagem para o seguinte endereço de e-mail:</p> <!-- Descrição sobre o e-mail -->
                <div class="social-links">
                    <!-- Link para o botão de enviar e-mail -->
                    <a href="mailto:senaipirituba@sp.senai.br" class="contact-button">Clique para Enviar E-mail</a> <!-- Link para abrir o cliente de e-mail -->
                </div>
            </div>

            <!-- Cartão Número de Contato -->
            <div class="contact-card">
                <h3>Telefone</h3> <!-- Título do cartão de telefone -->
                <p>Você pode nos contatar pelo número:</p> <!-- Descrição sobre o telefone -->
                <p class="contact-number">(11) 98765-4321</p> <!-- Número de telefone de contato -->
            </div>
        </div>

        <!-- Botão de Voltar -->
        <a href="javascript:history.back()" class="back-button">Voltar</a> <!-- Link de volta para a página anterior -->
    </body>
</html>
