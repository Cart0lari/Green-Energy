<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistemas Inteligentes de Armazenamento de Energia</title>
    <!-- <link rel="stylesheet" href="styles_baterias_blade.css"> -->
    <link rel="stylesheet" href="../../public/css/styles_artigos.css">
    <style>
        .centralizando {
            text-align: center;
            align-items: center;
            align-self: center;
        }

        .comentario_artigo {
            margin: 20px;
        }

        .comentario_artigo form {
            margin-bottom: 20px;
        }

        .comentario_artigo textarea {
            align-items: center;
            width: 85%;
            height: 150px;
            padding: 10px 10px 10px;
            margin-bottom: 10px;
            border: 1px solid #000000;
            border-radius: 5px;
        }

        .comentario_artigo button {
            background-color: #006400;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .comentario_artigo button:hover {
            background-color: #0056b3;  
        }

        .comentario {
            text-align: center;
            height: auto;
            width: center;
            margin-bottom: 10px;
            border: 1px solid #888;
            padding: 10px 1px 15px;
            border-radius: 5px;
        }

        .comentario strong {
            display: block;
            font-weight: bold;
        }

        .comentario i {
            font-size: 0.9em;
            color: #888;
        }
    </style>
        
</head>
<body>
    <?php 

    session_start(); // Inicia a sessão para verificar o login

    $usuarioLogado = isset($_SESSION['usuario']) ? $_SESSION['usuario'] : null;

    // Redireciona para o login se não estiver logado
    if (!isset($_SESSION['usuario'])) {
        header("Location: ./login.php");
        exit();
    }
    
    if ($_SESSION['usuario'] === 'Administrador') {
        $usuarioNome = 'Administrador';
        $paginaAdm = '<a href="./admin/pagina_adm.php">Página Administrador</a>';
    } else {
        $usuarioNome = $usuarioLogado;
        $paginaAdm = "";
    }
    ?>
    <div class="container">

        <header class="header">
        <img src="../../public/imagens/logo.png" alt="Logo" class="logo">
        <div class="nav-links">
                <p class="centralizando"><span class="texto_verde">Bem-vindo, <?php echo $usuarioLogado; ?></span></p>
                <div class="nav-links-right">
                    <a href="./logout.php">Logout</a>
                    <a href="../contato/contato.php">Contato</a>                  
                    <a href="../index.php" class="back-button">Voltar</a>
                </div>
            </div>
        </header>

        <br><h1 class="main-title">O Que é o Sistema de Rolo Suíço ou Micro-Origami? Descubra Como a Ciência Está Criando Estruturas Microscópicas Incríveis!</h1>

        <section class="content">
            <div class="video-container">
                <video class="rounded-video" autoplay muted loop width="600" height="350">
                <source src="../../public/videos/videoplayback_microbaterias.mp4" type="video/mp4">
                Seu navegador não suporta a tag de vídeo.
                </video>

            </div>

            <div class="text">
                <h2 class="centralizando">Introdução</h2>
                <p>Já imaginou um material que, ao sofrer um pequeno "deslizar", se enrola sozinho em uma forma cilíndrica minúscula? Essa incrível capacidade de transformação está no coração de uma inovação científica chamada <b>sistema de rolo suíço</b>, ou <b>micro-origami</b>. Embora o nome "origami" nos remeta ao ato de dobrar papel, no caso do micro-origami, a ideia é muito mais sobre como camadas finas de materiais podem se enrolar em escalas microscópicas, criando estruturas de tamanho tão pequeno que podem ser comparadas ao tamanho de um grão de sal.
                Neste artigo, vamos explorar esse fascinante sistema, entender como ele funciona e descobrir as potenciais aplicações que ele pode ter para a ciência e a tecnologia no futuro.</p><br>

        </section><br><br>

        <div class="text2">
            <h2>O Que é o Sistema de Rolo Suíço ou Micro-Origami?</h2>

            <p>O sistema de rolo suíço é uma técnica que envolve a criação de estruturas microscópicas que se enrolam automaticamente ao liberar a tensão de camadas finas de materiais. Essas camadas, quando tensionadas e depois relaxadas, formam uma estrutura cilíndrica de tamanho extremamente pequeno, com menos de um milímetro quadrado de área útil – quase do tamanho de um grão de sal. <br>
            O nome "micro-origami" vem do fato de que esse processo pode ser comparado ao conceito de origami, ou a arte de dobrar papel. Porém, no micro-origami, o material não é dobrado por mãos humanas, mas sim por forças mecânicas muito pequenas e controladas.</p>
        </div>

        <div class="text2">
            <h2>Como Funciona o Micro-Origami?</h2>
            <img src="../../public/imagens/menor_bateria_do_mundo.jpg" alt=""><br><br>
            <h3 style="color:#006400;">Tensão Mecânica Aplicada</h3><br>
            <p> Primeiro, uma força é aplicada a essas camadas finas, geralmente de forma controlada. A tensão que ocorre nesse processo é suficiente para fazer as camadas se deformarem e se ajustarem.</p>

            <h3 style="color:#006400;">Relaxamento das Camadas</h3><br>
            <p>Quando a tensão é liberada, as camadas relaxam e, como resultado, elas voltam a se enrolar, de forma quase automática, formando uma estrutura cilíndrica. A "mágica" aqui é que esse processo ocorre sem a necessidade de intervenção humana ou de movimentos adicionais complexos – é uma reação natural do material.</p>

            <h3 style="color:#006400;">Estrutura Cilíndrica Microscópica</h3><br>
            <p>O resultado final é uma estrutura extremamente pequena, com um diâmetro equivalente ao de um grão de sal. Isso pode parecer impressionante, mas esse tamanho reduzido é justamente o que torna o sistema tão promissor para diversas aplicações tecnológicas.</p><br>
        </div>
        
        <div class="text2">
            <h2>Potenciais Aplicações do Micro-Origami </h2>
            <p>O sistema de micro-origami tem um grande potencial para aplicações em áreas como <b>engenharia</b>, <b>eletrônica</b> e <b>medicina</b>, graças à sua capacidade de criar estruturas microscópicas com alta precisão e eficiência. Vamos dar uma olhada em algumas dessas possíveis aplicações.</p>

            <h3 style="color:#006400;">Dispositivos Eletrônicos em Escala Microscópica</h3><br>
            <p> A miniaturização de dispositivos eletrônicos é uma tendência crescente, e o micro-origami pode ser a chave para o desenvolvimento de <b>circuitos e sensores</b> muito pequenos. Esses componentes poderiam ser usados em uma série de dispositivos, desde smartphones até aparelhos médicos. A capacidade de criar componentes minúsculos, como <b>sensores de pressão</b> ou <b>sensores de temperatura</b>, que ocupam menos espaço e consomem menos energia, poderia abrir novos horizontes para a eletrônica portátil e outros dispositivos do futuro.</p>

            <h3 style="color:#006400;">Aplicações Médicas: Sensores e Implantes</h3><br>
            <p>Em <b>medicina</b>, o micro-origami poderia ser usado para criar <b>sensores biomédicos</b> de tamanho reduzido, capazes de monitorar condições de saúde em tempo real. Esses sensores poderiam ser implantados de maneira minimamente invasiva para monitoramento constante de parâmetros como temperatura, pressão arterial ou níveis de glicose, por exemplo. 
            <br>
            Além disso, a criação de <b>dispositivos microscópicos</b> para administrar medicamentos de forma controlada, ou para realizar diagnósticos de maneira mais eficiente, pode transformar o tratamento de várias doenças.</p>

            <h3 style="color:#006400;">Desenvolvimento de Materiais Autossustentáveis</h3><br>
            <p>A técnica também pode ser útil no desenvolvimento de <b>materiais inteligentes</b>. Imagine materiais que podem se <b>autoajustar</b> a diferentes condições, como mudanças de temperatura ou pressão. Isso é possível graças à flexibilidade e à capacidade de "relaxamento" das camadas de material, o que permite criar superfícies que se adaptam automaticamente a novos estímulos.</p>
        </div>

        <div class="text2">
            <h2>Vantagens do Micro-Origami </h2>
            
            <span class="centralizando"><b>O uso do sistema de rolo suíço e micro-origami oferece algumas vantagens significativas</b></span><br><br>

            <p> <span class="artigo">Miniaturização</span>: criar dispositivos minúsculos é um grande passo para o desenvolvimento de tecnologias mais compactas e eficientes. <br>
            
            <span class="artigo">Precisão</span>: as estruturas geradas são extremamente precisas, com dimensões tão pequenas que tornam possíveis aplicações em escalas muito reduzidas. <br>
            
            <span class="artigo">Eficiência</span>: O processo de relaxamento das camadas e a formação automática da estrutura tornam o sistema altamente eficiente e de baixo custo, uma vez que elimina a necessidade de intervenções complexas.</p>
        </div>

        <div class="text2">
            <h2>Desafios e Limitações</h2>
            
            <span class="centralizando"><b>Embora o micro-origami tenha um grande potencial, ele também apresenta alguns desafios</b></span><br><br>

            <p> <span class="artigo">Controle de Processos</span>: O controle preciso da tensão mecânica e do processo de relaxamento das camadas é fundamental para garantir que as estruturas sejam formadas corretamente.<br>
            
            <span class="artigo">Materiais Adequados</span>: Nem todos os materiais são adequados para o processo de micro-origami, e encontrar os materiais ideais que sejam ao mesmo tempo flexíveis e duráveis para aplicações práticas ainda é um desafio.<br>
        
        </div><br>
        
    <section class="comentario_artigo">
        <div class="centralizando">
            <h2 class="text2">Deixe seu comentário</h2>
            <br>
            
            <form method="POST" action="../../controllers/controlador_comentarios.php">
                <textarea name="comentario" placeholder="Digite seu comentário aqui"></textarea><br>
                <button type="submit" name="botao_comentario">Enviar Comentário</button>
            </form>

            <!-- Mensagem de Sucesso ou Erro -->
            <p class="centralizando"><?php echo isset($_GET['comentarioEnviado']) ? $_GET['comentarioEnviado'] : ''; ?></p>
            <p class="centralizando" style="color: red;"><?php echo isset($_GET['erroMensagem']) ? $_GET['erroMensagem'] : ''; ?></p>

            <h3>Comentários</h3>
            <?php
                include("../../config/conexaoBD.php");
                
                $sql = "SELECT Cadastro.Nome, Comentarios.comentario, Comentarios.data 
                        FROM Comentarios 
                        INNER JOIN Cadastro ON Comentarios.IdCadastro = Cadastro.IdCadastro 
                        ORDER BY Comentarios.data DESC";

                $result = $conexao->query($sql);
                
                if ($result && $result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="comentario">';
                            echo '<strong>' . htmlspecialchars($row['Nome']) . '</strong>';
                            echo '<p>' . htmlspecialchars($row['comentario']) . '</p>';
                            echo '<p><i>' . date('d/m/Y H:i', strtotime($row['data'])) . '</i></p>';
                        echo '</div>';
                    }
                } else {
                    echo '<p>Nenhum comentário encontrado.</p>';
                }
            ?>
        </div>
    </section>
</body>
</html>
