<?php
// Percentual inicial da bateria fornecido pelo usuário
$percentual_inicial = isset($_POST['percentual_inicial']) ? (float)$_POST['percentual_inicial'] : null;

if ($percentual_inicial !== null && $percentual_inicial >= 0 && $percentual_inicial <= 100) {
    // Verifica se o percentual inicial está dentro do intervalo válido (0 a 100)
    
    // Taxa de carregamento por quilômetro
    $carregamento_por_km = 4; // 4% por quilômetro
    
    // Calcula o percentual restante para completar 100%
    $percentual_restante = 100 - $percentual_inicial;
    
    // Calcula os quilômetros necessários
    $kms_necessarios = $percentual_restante / $carregamento_por_km;
    
    $mensagem = "Com a bateria em $percentual_inicial%, o carro precisa percorrer $kms_necessarios km para carregar completamente.";
} else {
    $mensagem = "Por favor, insira um valor válido para o percentual da bateria (entre 0 e 100)";
}
?>

<!-- HTML com formulário -->
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carregamento da Bateria</title>
    <link rel="stylesheet" href="../../public/css/processo_style.css">
</head>
<body>
    <div class="container">
        <!-- Exibe a mensagem para o usuário -->
        <p class="mensagem">
            <b><?php echo $mensagem; ?></b>
        </p>

        <!-- Formulário -->
        <form method="post">
            <label for="percentual_inicial"><b>Digite o percentual atual da bateria (%)</b></label>
            <br><br>
            <input type="number" id="percentual_inicial" name="percentual_inicial" step="0.1" min="0" max="100" required>
            <button type="submit"><b>Calcular</b></button>
        </form>
        <!-- Botão de Voltar -->
        <button><a class="a" href="../login/artigo_2.php"><b>Voltar</b></a>
        </button>
    </div>
</body>
</html>
