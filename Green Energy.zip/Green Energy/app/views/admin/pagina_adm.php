<?php
session_start();

include_once("../../controllers/controlador_administrador.php");

$mensagemADM = isset($_SESSION['mensagemADM']) ? $_SESSION['mensagemADM'] : null;
$mensagem = isset($_SESSION['mensagem']) ? $_SESSION['mensagem'] : null;

unset($_SESSION['mensagemADM']);
unset($_SESSION['mensagem']);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuários Cadastrados</title>
    <link rel="stylesheet" href="../../public/css/adm_style.css">
</head>
<body>
    <h1>Usuários e Comentários</h1>
    
    <?php if ($mensagemADM): ?>
        <p style="color: red; text-align: center;"><?= htmlspecialchars($mensagemADM) ?></p>
    <?php endif; ?>
    <?php if ($mensagem): ?>
        <p style="color: green; text-align: center;"><?= htmlspecialchars($mensagem) ?></p>
    <?php endif; ?>

    <form method="get">
        <label for="nome">Filtrar por Nome:</label>
        <select id="nome" name="nome">
            <option value="">-- Todos os Usuários --</option>
            <?php foreach ($listaNomes as $nome): ?>
                <option value="<?= htmlspecialchars($nome) ?>" <?= $nomeFiltro === $nome ? 'selected' : '' ?>>
                    <?= htmlspecialchars($nome) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <br><br>
        <label for="comentario">Filtrar por Comentário:</label>
        <input type="text" id="comentario" name="comentario" value="<?= htmlspecialchars($comentarioFiltro) ?>">
        <br><br>
        <button type="submit">Aplicar Filtros</button>
        <button type="button" onclick="window.location.href='pagina_adm.php';">Limpar Filtros</button>
    </form>
    <br>
    <table border="1">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Data de Nascimento</th>
                <th>Telefone</th>
                <th>CPF</th>
                <th>Endereço</th>
                <th>Comentários</th>
                <th>Status</th>
                <th>Bloquear</th>
                <th>Deletar</th>
                <th>Apagar Comentario</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($usuarios as $usuario): ?>
                <tr>
                    <td><?= htmlspecialchars($usuario['Nome']) ?></td>
                    <td><?= htmlspecialchars($usuario['Email']) ?></td>
                    <td><?= htmlspecialchars($usuario['Datanascimento']) ?></td>
                    <td><?= htmlspecialchars($usuario['Telefone']) ?></td>
                    <td><?= htmlspecialchars($usuario['CPF']) ?></td>
                    <td><?= htmlspecialchars($usuario['Endereco']) ?></td>
                    <td><?= htmlspecialchars($usuario['comentarioTexto']) ?></td>
                    <td><?= htmlspecialchars($usuario['status']) ?></td>
                    <td>
                        <a href="pagina_adm.php?bloquear=<?= $usuario['IdCadastro'] ?>">
                            <?= $usuario['status'] === 'ativo' ? 'Bloquear' : 'Desbloquear' ?>
                        </a>
                    </td>
                    <td>
                        <a href="pagina_adm.php?deletar=<?= $usuario['Email'] ?>">Deletar</a>
                        <?php if ($usuario['IdComentario']): ?>
                    </td>
                    <td>
                            <a href="pagina_adm.php?deletarComentario=<?= $usuario['IdComentario'] ?>">Excluir Comentário</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <br>
    <button type="button" onclick="window.location.href='../index.php';">Voltar para Index</button>
    <br><br>
    <button type="button" onclick="window.location.href='../login/logout.php';">Logout</button>
</body>
</html>
