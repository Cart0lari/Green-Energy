<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$erroMensagem = isset($_SESSION['erroCadastro']) ? $_SESSION['erroCadastro'] : null;
unset($_SESSION['erroCadastro']); // Limpa a mensagem após exibir
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário</title>
    <link rel="stylesheet" href="../../public/css/formulario_style.css">
</head>
<body>
    <!-- Contêiner do formulário -->
    <div class="form-container">
        <h2>Cadastro de Usuário</h2>
        <!-- Formulário -->
        <form action="../../controllers/controlador_formulario.php" method="POST">
            <label for="nome">Nome Completo</label>
            <input type="text" id="nome" name="nome" placeholder="Digite seu nome" required><br>

            <label for="email">E-mail</label>
            <input type="email" id="email" name="email" placeholder="exemplo@dominio.com" required><br>

            <label for="datanascimento">Data de Nascimento</label>
            <input type="date" id="datanascimento" name="datanascimento" required><br>

            <label for="telefone">Telefone</label>
            <input type="text" id="telefone" name="telefone" placeholder="(XX) XXXXX-XXXX" required><br>

            <label for="cpf">CPF</label>
            <input type="text" id="cpf" name="cpf" placeholder="XXX.XXX.XXX-XX" required><br>

            <label for="endereco">Endereço</label>
            <input type="text" id="endereco" name="endereco" placeholder="Rua, Número, Bairro" required><br>

            <!--Deste modo a senha agora te´ra um parametro para ser mais segura -->
            <label for="senha">Senha</label>
            <input type="password" id="senha" name="senha" placeholder="Digite sua senha" 
            pattern="^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$" 
            title="A senha deve conter pelo menos 8 caracteres, incluindo uma letra maiúscula, uma minúscula, um número e um caractere especial." required><br>
            
            <!--Confirmação da senha para login  -->
            <label for="senha">Confirme a senha</label>
            <input type="password" id="confirmasenha" name="confirmasenha" placeholder="Digite sua senha" 
            pattern="^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$" 
            title="As senhas não estão iguais!" required><br>


            <input type="submit" name="cadastrar" value="Cadastrar"><br>

            <?php if ($erroMensagem): ?>
                <p class="error-message"><?php echo $erroMensagem; ?></p>
            <?php endif; ?>

        </form>
    </div>
</body>
</html>
