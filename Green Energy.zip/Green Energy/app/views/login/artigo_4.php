<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistemas Inteligentes de Armazenamento de Energia</title>
     <link rel="stylesheet" href="../../public/css/styles_artigos.css">
     <style>
        .centralizando {
            text-align: center;
            align-items: center;
            align-self: center;
        }

        .comentario_artigo {
            margin: 20px;
        }

        .comentario_artigo form {
            margin-bottom: 20px;
        }

        .comentario_artigo textarea {
            align-items: center;
            width: 85%;
            height: 150px;
            padding: 10px 10px 10px;
            margin-bottom: 10px;
            border: 1px solid #000000;
            border-radius: 5px;
        }

        .comentario_artigo button {
            background-color: #006400;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .comentario_artigo button:hover {
            background-color: #0056b3;  
        }

        .comentario {
            text-align: center;
            height: auto;
            width: center;
            margin-bottom: 10px;
            border: 1px solid #888;
            padding: 10px 1px 15px;
            border-radius: 5px;
        }

        .comentario strong {
            display: block;
            font-weight: bold;
        }

        .comentario i {
            font-size: 0.9em;
            color: #888;
        }
    </style>
    
    <?php 

        session_start(); 
        
        $usuarioLogado = isset($_SESSION['usuario']) ? $_SESSION['usuario'] : null;

        // Redireciona para o login se não estiver logado
        if (!isset($_SESSION['usuario'])) {
            header("Location: ./login.php");
            exit();
        }

        if ($_SESSION['usuario'] === 'Administrador') {
            $usuarioNome = 'Administrador';
            $paginaAdm = '<a href="./admin/pagina_adm.php">Página Administrador</a>';
        } else {
            $usuarioNome = $usuarioLogado;
            $paginaAdm = "";
        }
    ?>

</head>
<body>
    <div class="container">

        <header class="header">
        <img src="../../public/imagens/logo.png" alt="Logo" class="logo">
            <div class="nav-links">
                <p class="centralizando"><span class="texto_verde">Bem-vindo, <?php echo $usuarioLogado; ?></span></p>
                <div class="nav-links-right">
                    <a href="./logout.php">Logout</a>
                    <a href="../contato/contato.php">Contato</a>                  
                    <a href="../index.php" class="back-button">Voltar</a>
                </div>
            </div>
        </header>

        <br><h1 class="main-title">Venda de Energia Solar no Brasil: Como Funciona e Oportunidades para Consumidores e Produtores</h1>
        <section class="content">
            <div class="video-container">
                <video class="rounded-video" autoplay muted loop width="440" height="250">
                <source src="../../public/videos/venda_solar.mp4" type="video/mp4">
                    Seu navegador não suporta a tag de vídeo.
                </video>
            </div>

            <div class="text">
                <h2>Introdução </h2>
                <p>Com o crescente interesse por fontes de energia renováveis, a <b>energia solar</b> se destaca como uma das alternativas mais viáveis e sustentáveis para a geração de eletricidade. Além de reduzir a dependência de fontes de energia não renováveis, como os combustíveis fósseis, a energia solar também oferece oportunidades econômicas para consumidores e empresas. Muitos se perguntam: <b>é possível vender energia solar?</b> A resposta é sim! No Brasil, existem diferentes maneiras de comercializar a energia gerada por sistemas fotovoltaicos, seja no mercado regulamentado ou por meio de créditos de energia. Neste artigo, vamos explorar como funciona o processo de venda de energia solar e quais as oportunidades para quem gera eletricidade a partir do sol.</p>
        </section>
        
        <div class="text2">
            <h2>Venda de Energia Solar por Meio de Leilões Regulamentados pela ANEEL</h2>
            <img src="" alt="">

            <p>Uma das formas mais comuns de vender energia solar no Brasil é através dos <b>leilões de energia</b> organizados pela <b>ANEEL</b> (Agência Nacional de Energia Elétrica). Esses leilões são eventos públicos realizados para a contratação de energia de diferentes fontes, como hidrelétricas, parques eólicos e usinas solares.</p>
            
            <h3 style="color:#006400;">Como funciona ?</h3><br>

            <p><span class="artigo"><b>Leilões Regulatórios</b></span>: A ANEEL realiza leilões em que empresas e investidores podem competir para fornecer energia para o sistema elétrico nacional. No caso da energia solar, projetos de <b>usinas fotovoltaicas</b> podem participar, oferecendo a energia gerada para distribuição por meio de contratos de longo prazo com distribuidoras de energia.<br>
            <span class="artigo"><b>Contratos de Compra</b></span>: Quando um projeto solar vence um leilão, ele firma um contrato com a distribuidora, que adquire a energia a um preço fixo e acordado por um período determinado, geralmente de 20 a 30 anos. A energia é, então, entregue diretamente à rede elétrica, e o proprietário da usina solar recebe uma remuneração por isso.</p>
            <img src="../../public/imagens/venda_de_energia_solar.png" alt="Logo" class="logo">

            <h3 style="color:#006400;">Vantagens</h3><br>
            <p><span class="artigo"><b>Previsibilidade Financeira</b></span>: Os leilões oferecem contratos de longo prazo com preços fixos, o que garante previsibilidade de receita para quem investe na geração de energia solar. <br>
            <span class="artigo"><b>Apoio Governamental</b></span>: A participação em leilões regulados é uma oportunidade para usinas solares que buscam garantir contratos de fornecimento de energia com distribuidoras, com o apoio de políticas públicas que incentivam a expansão de energias renováveis no país.
            </p>

            <h3 style="color:#006400;">Desafios</h3><br>
            <p><span class="artigo"><b>Concorrência e Custos</b></span>: Os leilões podem ser altamente competitivos, e os preços oferecidos nem sempre são elevados, o que pode reduzir a rentabilidade para alguns projetos. Além disso, o custo de implantação de uma usina solar de grande porte pode ser elevado, o que exige um alto nível de investimento inicial.</p>

        </div><br>

        <div class="text2">
            <h2>Venda de Energia no Mercado Livre de Energia</h2>
            <p><span class="centralizando">Outra forma de comercializar energia solar no Brasil é através do <b>mercado livre de energia</b>. Este mercado permite que consumidores e produtores de energia negociem contratos de compra e venda diretamente, sem a intermediação das distribuidoras locais.</span></p>
            <img src="" alt="">
            <br><h3 style="color:#006400;">Como Funciona</h3><br>
            <p><span class="artigo"><b>Contratação Direta</b></span>: No mercado livre, empresas que possuem sistemas de geração de energia solar (ou outras fontes) podem vender a energia diretamente para consumidores finais, como indústrias ou grandes comércios. A negociação é feita por meio de contratos bilaterais, onde as partes acordam preços, prazos e volumes de energia. <br>
            <span class="artigo"><b>Venda para Grandes Consumidores</b></span>: Uma das principais características do mercado livre é que apenas consumidores com demanda superior a 500 kW de energia podem negociar diretamente com os geradores, como usinas solares. No entanto, com a expansão do mercado livre e a evolução das regulamentações, existe a possibilidade de pequenos geradores de energia também poderem participar de algumas modalidades de venda. </p>

            <h3 style="color:#006400;">Vantagens</h3><br>
            <p><span class="artigo"><b>Preços Competitivos</b></span>: O mercado livre tende a ser mais flexível e competitivo, o que pode resultar em preços mais baixos para quem compra e maiores margens de lucro para quem vende. 
            <br>
            <span class="artigo"><b>Maior Flexibilidade</b></span>: As negociações são mais flexíveis e personalizáveis, permitindo que o produtor de energia solar estabeleça contratos de acordo com suas necessidades e com as de seus compradores.</p>

            <h3 style="color:#006400;">Desafios</h3><br>
            <p><span class="artigo"><b>Regulamentação Complexa</b></span>: Embora o mercado livre tenha se expandido no Brasil, ele ainda envolve uma complexa regulamentação, que exige conhecimento técnico e jurídico para operar de forma eficiente. 
            <br> 
            <span class="artigo"><b>Necessidade de Infraestrutura</b></span>: Para atuar no mercado livre, os produtores de energia solar precisam ter infraestrutura adequada para a transmissão e medição de energia, além de cumprir com diversas exigências legais. </p>

        </div>
        <br>
        <div class="text2">
            <h2>Vender Energia Solar para a Rede Distribuidora: Créditos de Energia</h2>
            <p>Uma das maneiras mais acessíveis para quem possui um sistema de energia solar fotovoltaica em sua residência ou empresa é <b>vender energia para a rede distribuidora</b> e receber créditos em troca. Isso é possível por meio do sistema de <b>net metering</b>, regulamentado pela ANEEL.</p>
            <img src="" alt="">

            <h3 style="color:#006400;">Como funciona</h3><br>
            <p><span class="artigo"><b>Geração e Consumo</b></span>: Quando você instala um sistema solar em sua casa ou empresa, pode gerar mais energia do que consome, especialmente em períodos de alta incidência solar. Nesse caso, a energia excedente é enviada para a rede elétrica, e você recebe créditos equivalentes ao valor da energia que injetou na rede. 
            <br> 
            <span class="artigo"><b>Compensação de Energia</b></span>: Esses créditos podem ser utilizados posteriormente para abater o valor da sua conta de energia, quando a geração solar não for suficiente para cobrir o consumo (por exemplo, à noite ou em dias nublados). O saldo de créditos pode ser acumulado por até 60 meses, o que permite um "estoque" de energia que pode ser utilizado conforme a necessidade.</p>

            <h3 style="color: #006400;">Vantagens</h3><br>
            <p><span class="artigo"><b>Facilidade e Acessibilidade</b></span>: A venda de energia para a rede elétrica por meio de créditos de energia é uma das opções mais acessíveis para consumidores residenciais ou pequenos negócios. O processo é simples e não exige grandes investimentos em infraestrutura. <br>
            <span class="artigo"><b>Economia de Energia</b></span>: O principal benefício é a redução da conta de energia elétrica, já que você pode compensar os custos com a energia que gerou e enviou para a rede.
            </p>

            <h3 style="color: #006400;">Desafios</h3><br>
            <p><span class="artigo"><b>Limitações de Geração</b></span>: A quantidade de energia que pode ser injetada na rede depende da capacidade do sistema fotovoltaico instalado. Além disso, a compensação de energia pode ser limitada por regras locais ou mudanças nas políticas de net metering. <br>
            <span class="artigo"><b>Prazo de Retorno</b></span>: Embora o sistema de créditos seja vantajoso, o retorno sobre o investimento inicial em sistemas solares pode ser mais lento, especialmente em residências que consomem pouca energia.
            </p>

        </div>

        <div class="text2">
            <h2>Conclusão</h2>
            <img src="" alt="">
            
            <p>Vender energia solar no Brasil é uma realidade possível e viável, com várias formas de comercialização que atendem tanto a grandes produtores quanto consumidores residenciais. Seja através dos leilões regulados pela ANEEL, no mercado livre de energia ou por meio de créditos de energia com a rede distribuidora, as opções são diversificadas e podem ser adaptadas de acordo com as necessidades e capacidade de geração de cada projeto. <br>
            O crescimento da energia solar no Brasil, aliado a um ambiente regulatório em evolução, abre um leque de oportunidades para quem deseja se envolver no mercado de energia renovável, seja para gerar receita, reduzir custos ou contribuir para um futuro mais sustentável. </p>
        </div><br>
    </div>
        <section class="comentario_artigo">
            <div class="centralizando">
                <h2 class="text2">Deixe seu comentário</h2>
                <br>
                
                <form method="POST" action="../../controllers/controlador_comentarios.php">
                    <textarea name="comentario" placeholder="Digite seu comentário aqui"></textarea><br>
                    <button type="submit" name="botao_comentario">Enviar Comentário</button>
                </form>

                <p class="centralizando"><?php echo isset($_GET['comentarioEnviado']) ? $_GET['comentarioEnviado'] : ''; ?></p>
                <p class="centralizando" style="color: red;"><?php echo isset($_GET['erroMensagem']) ? $_GET['erroMensagem'] : ''; ?></p>

                <h3>Comentários</h3>
                <?php
                
                    include("../../config/conexaoBD.php");
                    
                    $sql = "SELECT Cadastro.Nome, Comentarios.comentario, Comentarios.data 
                            FROM Comentarios 
                            INNER JOIN Cadastro ON Comentarios.IdCadastro = Cadastro.IdCadastro 
                            ORDER BY Comentarios.data DESC";

                    $result = $conexao->query($sql);
                    
                    if ($result && $result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo '<div class="comentario">';
                            echo '<strong>' . htmlspecialchars($row['Nome']) . '</strong>';
                            echo '<p>' . htmlspecialchars($row['comentario']) . '</p>';
                            echo '<p><i>' . date('d/m/Y H:i', strtotime($row['data'])) . '</i></p>';
                            echo '</div>';
                        }
                    } else {
                        echo '<p>Nenhum comentário encontrado.</p>';
                    }
                ?>
            </div>
        </section>
</body>
</html>
