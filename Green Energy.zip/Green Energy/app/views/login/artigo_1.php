<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistemas Inteligentes de Armazenamento de Energia</title>
    <link rel="stylesheet" href="../../public/css/styles_artigos.css">
    <style>
        .centralizando {
            text-align: center;
            align-items: center;
            align-self: center;
        }

        .comentario_artigo {
            margin: 20px;
        }

        .comentario_artigo form {
            margin-bottom: 20px;
        }

        .comentario_artigo textarea {
            align-items: center;
            width: 85%;
            height: 150px;
            padding: 10px 10px 10px;
            margin-bottom: 10px;
            border: 1px solid #000000;
            border-radius: 5px;
        }

        .comentario_artigo button {
            background-color: #006400;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .comentario_artigo button:hover {
            background-color: #0056b3;  
        }

        .comentario {
            text-align: center;
            height: auto;
            width: center;
            margin-bottom: 10px;
            border: 1px solid #888;
            padding: 10px 1px 15px;
            border-radius: 5px;
        }

        .comentario strong {
            display: block;
            font-weight: bold;
        }

        .comentario i {
            font-size: 0.9em;
            color: #888;
        }
    </style>
</head>
<body>
    <?php 

    session_start(); // Inicia a sessão para verificar o login

    $usuarioLogado = isset($_SESSION['usuario']) ? $_SESSION['usuario'] : null;

    // Redireciona para o login se não estiver logado
    if (!isset($_SESSION['usuario'])) {
        header("Location: ./login.php");
        exit();
    }

    if ($_SESSION['usuario'] === 'Administrador') {
        $usuarioNome = 'Administrador';
        $paginaAdm = '<a href="./admin/pagina_adm.php">Página Administrador</a>';
    } else {
        $usuarioNome = $usuarioLogado;
        $paginaAdm = "";
    }
    ?>
    <div class="container">
        <header class="header">
            <img src="../../public/imagens/logo.png" alt="Logo" class="logo">
            <div class="nav-links">
                <p class="centralizando"><span class="texto_verde">Bem-vindo, <?php echo $usuarioLogado; ?></span></p>
                <div class="nav-links-right">
                    <a href="./logout.php">Logout</a>
                    <a href="../contato/contato.php">Contato</a>                  
                    <a href="../index.php" class="back-button">Voltar</a>
                </div>
            </div>
        </header>

        <br><h1 class="main-title">Baterias Blade da BYD: Segurança e Inovação no Futuro dos Veículos Elétricos</h1>

        <section class="content">
            <div class="video-container">
                <video class="rounded-video" autoplay muted loop width="440" height="250">
                    <source src="../../public/videos/videoplayback_BYD.mp4" type="video/mp4">
                    Seu navegador não suporta a tag de vídeo.
                </video>
                <video class="rounded-video" autoplay muted loop width="440" height="250">
                    <source src="../../public/videos/videoplayback_BYD2.mp4" type="video/mp4">
                    Seu navegador não suporta a tag de vídeo.
                </video>
            </div>
            <div class="text">
                <h2 class="centralizando">Introdução</h2>
                <p>Com a crescente popularidade dos <b>veículos elétricos (VEs)</b>, a <b>segurança das baterias</b> se tornou uma das questões mais cruciais para os fabricantes e consumidores. As baterias são o coração dos carros elétricos, e garantir que elas sejam <b>seguras, duráveis e eficientes</b> é essencial para o avanço do setor de mobilidade elétrica. Nesse contexto, a <b>BYD</b>, uma das líderes globais no desenvolvimento de soluções de mobilidade elétrica e energia renovável, apresentou uma inovação que promete mudar os padrões de segurança no mercado: as <b>Baterias Blade</b>.</p>

                <p>Essas baterias representam um avanço significativo em termos de <b>segurança, eficiência energética e sustentabilidade</b>. O destaque das <b>Baterias Blade</b> não está apenas no desempenho, mas também nos <b>testes rigorosos</b> que demonstram a superioridade das baterias em situações extremas, como os famosos <b>Nail Penetration Tests</b>. Neste artigo, vamos explorar o que torna as <b>Baterias Blade</b> da BYD tão inovadoras e como elas estão definindo um novo padrão para a indústria de <b>veículos elétricos</b>. </p><br>
            </div>
        </section>

        <div class="text2">
            <h2>O que São as Baterias Blade? </h2>
            <img src="../../public/imagens/Blade-battery_PC.png" alt="">

            <p>As <b>Baterias Blade</b> são uma nova geração de baterias desenvolvidas pela <b>BYD</b>, que utilizam a <b>tecnologia de fosfato de ferro-lítio (LiFePO4)</b>, um tipo de <b>bateria de lítio</b>. Embora as baterias de <b>lítio</b> já sejam amplamente utilizadas em veículos elétricos, a principal inovação da <b>Bateria Blade</b> é a <b>forma</b> e a <b>estratégia de segurança</b> incorporadas ao seu design.</p><br>

            <p>Em vez de ser composta por células de bateria agrupadas em módulos tradicionais, as <b>Baterias Blade</b> da BYD são constituídas por <b>blades</b> (lâminas) finas e longas, que são instaladas de maneira compacta e eficiente no interior do veículo. Esse design não apenas melhora a densidade energética, mas também contribui para a <b>maior segurança</b> e <b>resistência</b> da bateria, minimizando riscos de falhas térmicas e incêndios. </p>
        </div><br>

        <div class="text2">
            <h2>O Nail Penetration Test: Um Teste Rigoroso de Segurança</h2>

            <p>Uma das maiores inovações das Baterias Blade da BYD é a forma como elas passaram por testes de segurança avançados. O mais notável é o "Nail Penetration Test", que simula um acidente grave envolvendo perfuração das baterias.</p><br>

            <p>O <b>Nail Penetration Test</b> (Teste de Perfuração com Prego) é um teste de segurança amplamente utilizado na indústria automotiva e de baterias para simular o impacto de um acidente grave. No caso específico das baterias de lítio, esse teste é feito perfurando uma célula de bateria com um prego ou outro objeto metálico pontiagudo. O objetivo é avaliar como a bateria reage a um impacto que poderia danificar suas células e, em última instância, causar <b>fuga térmica</b> - o que pode resultar em incêndios ou explosões.</p>

            <p>Este teste é crucial porque, no caso das baterias convencionais de íon-lítio, danos físicos podem levar a reações <b>térmicas descontroladas</b>, criando riscos de <b>incêndios</b> ou até <b>explosões</b>. No entanto, as <b>Baterias Blade</b> da <b>BYD</b> se destacaram ao <b>superar</b> amplamente os requisitos de segurança estabelecidos por esse teste, oferecendo uma proteção muito mais robusta e confiável.</p>
        </div>

        <div class="text2">
            <h2>Superando os Testes de Segurança O Desempenho das Baterias Blade</h2>
            <img src="../../public/imagens/byd-blade-e-platform30.jpg" alt="">

            <p>Nos testes realizados pela <b>BYD</b>, as <b>Baterias Blade</b> mostraram um desempenho impressionante, permanecendo <b>estáveis</b> e seguras mesmo após serem perfuradas com o prego, o que, em condições normais, causaria o início de um processo térmico perigoso em baterias de tecnologia tradicional.</p>

            <p>O que torna as <b>Baterias Blade</b> mais seguras do que as baterias convencionais é o <b>design inovador</b> e a <b>química interna</b>. Quando uma célula da bateria é perfurada, ela não sofre o mesmo tipo de reação <b>exotérmica</b> (liberação excessiva de calor) que pode ocorrer em outras baterias de íon-lítio. Em vez disso, a <b>Bateria Blade</b> mantém a temperatura sob controle, evitando o risco de <b>incêndios</b> ou <b>explosões</b>, o que representa uma melhoria significativa na <b>segurança passiva</b> dos veículos elétricos.</p>
                
            <p>A <b>BYD</b> também testou as <b>Baterias Blade</b> em outras condições extremas, como <b>altas temperaturas</b> e <b>cargas rápidas</b>, e a bateria continuou a operar com eficiência e segurança. Esse desempenho superior reflete a dedicação da empresa em melhorar a segurança e a confiabilidade de suas baterias, colocando a <b>BYD
            </b> na vanguarda do desenvolvimento de soluções de mobilidade elétrica. </p>
        </div>

        <div class="text2">
            <h2>Outros Benefícios das Baterias Blade</h2>

            <p>Além de sua segurança excepcional, as <b>Baterias Blade</b> oferecem outros benefícios que as tornam ideais para a mobilidade elétrica:</p>

            <p><b>Maior Densidade Energética</b>: O design das lâminas (blades) permite um uso mais eficiente do espaço dentro do compartimento da bateria, resultando em maior densidade energética. Isso se traduz em <b>maior autonomia</b> para os veículos elétricos, reduzindo a necessidade de recargas frequentes. </p>

            <p><b>Durabilidade e Longevidade</b>: As <b>Baterias Blade</b> têm uma vida útil mais longa em comparação com outras baterias de lítio. Isso é crucial para reduzir os custos operacionais de veículos elétricos ao longo do tempo e garantir que os motoristas possam aproveitar ao máximo seu investimento.</p>                
                
            <p><b>Sustentabilidade</b>: A <b>BYD</b> também se destaca pelo compromisso com a sustentabilidade, e as <b>Baterias Blade</b> são mais ecológicas em comparação com outras baterias, já que utilizam <b>fosfato de ferro-lítio</b>, que é mais abundante e menos tóxico do que outras químicas de lítio, como o <b>níquel</b> e o <b>cobalto</b>. </p>

        </div>
    </div>
        <section class="comentario_artigo">
            <div class="centralizando">
                <h2 class="text2">Deixe seu comentário</h2>
                <br>
                
                <form method="POST" action="../../controllers/controlador_comentarios.php">
                    <textarea name="comentario" placeholder="Digite seu comentário aqui"></textarea><br>
                    <button type="submit" name="botao_comentario">Enviar Comentário</button>
                </form>

                <p class="centralizando"><?php echo isset($_GET['comentarioEnviado']) ? $_GET['comentarioEnviado'] : ''; ?></p>
                <p class="centralizando" style="color: red;"><?php echo isset($_GET['erroMensagem']) ? $_GET['erroMensagem'] : ''; ?></p>

                <h3>Comentários</h3>
                <?php
                
                    include("../../config/conexaoBD.php");
                    
                    $sql = "SELECT Cadastro.Nome, Comentarios.comentario, Comentarios.data 
                            FROM Comentarios 
                            INNER JOIN Cadastro ON Comentarios.IdCadastro = Cadastro.IdCadastro 
                            ORDER BY Comentarios.data DESC";

                    $result = $conexao->query($sql);
                    
                    if ($result && $result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo '<div class="comentario">';
                            echo '<strong>' . htmlspecialchars($row['Nome']) . '</strong>';
                            echo '<p>' . htmlspecialchars($row['comentario']) . '</p>';
                            echo '<p><i>' . date('d/m/Y H:i', strtotime($row['data'])) . '</i></p>';
                            echo '</div>';
                        }
                    } else {
                        echo '<p>Nenhum comentário encontrado.</p>';
                    }
                ?>
            </div>
        </section>
</body>
</html>
