<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistemas Inteligentes de Armazenamento de Energia</title>
    <!-- <link rel="stylesheet" href="styles_baterias_blade.css"> -->
     <link rel="stylesheet" href="../../public/css/styles_artigos.css">
     <style>
        .centralizando {
            text-align: center;
            align-items: center;
            align-self: center;
        }

        .comentario_artigo {
            margin: 20px;
        }

        .comentario_artigo form {
            margin-bottom: 20px;
        }

        .comentario_artigo textarea {
            align-items: center;
            width: 85%;
            height: 150px;
            padding: 10px 10px 10px;
            margin-bottom: 10px;
            border: 1px solid #000000;
            border-radius: 5px;
        }

        .comentario_artigo button {
            background-color: #006400;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .comentario_artigo button:hover {
            background-color: #0056b3;  
        }

        .comentario {
            text-align: center;
            height: auto;
            width: center;
            margin-bottom: 10px;
            border: 1px solid #888;
            padding: 10px 1px 15px;
            border-radius: 5px;
        }

        .comentario strong {
            display: block;
            font-weight: bold;
        }

        .comentario i {
            font-size: 0.9em;
            color: #888;
        }
    </style>
</head>
<body>
    <?php 

    session_start(); // Inicia a sessão para verificar o login

    $usuarioLogado = isset($_SESSION['usuario']) ? $_SESSION['usuario'] : null;

    // Redireciona para o login se não estiver logado
    if (!isset($_SESSION['usuario'])) {
        header("Location: ./login.php");
        exit();
    }
    
    if ($_SESSION['usuario'] === 'Administrador') {
        $usuarioNome = 'Administrador';
        $paginaAdm = '<a href="./admin/pagina_adm.php">Página Administrador</a>';
    } else {
        $usuarioNome = $usuarioLogado;
        $paginaAdm = "";
    }
    ?>
    <div class="container">

        <header class="header">
            <img src="../../public/imagens/logo.png" alt="Logo" class="logo">
            <div class="nav-links">
                <p class="centralizando"><span class="texto_verde">Bem-vindo, <?php echo $usuarioLogado; ?></span></p>
                <div class="nav-links-right">
                    <a href="./logout.php">Logout</a>
                    <a href="../contato/contato.php">Contato</a>                  
                    <a href="../index.php" class="back-button">Voltar</a>
                </div>
            </div>
        </header>

        <br><h1 class="main-title">Armazenamento Gravitacional de Energia: Uma Solução Promissora para o Futuro da Energia Sustentável</h1>

        <section class="content">
            <div class="video-container">
                <video class="rounded-video" autoplay muted loop width="440" height="250">
                <source src="../../public/videos/videoplayback_energia_gravitacional.mp4" type="video/mp4">
                    Seu navegador não suporta a tag de vídeo.
                </video>
            </div>

            <div class="text">
                <h2>Introdução </h2>
                <p>À medida que o mundo se volta para fontes de energia renovável, como solar e eólica, a necessidade de soluções eficazes para o armazenamento de energia se torna cada vez mais urgente. As fontes renováveis são intermitentes, ou seja, não geram energia o tempo todo, e o armazenamento é fundamental para garantir uma oferta estável e contínua de eletricidade. Nesse contexto, o armazenamento gravitacional de energia surge como uma solução inovadora e promissora, utilizando a força da gravidade para armazenar e liberar energia de forma eficiente e com baixo impacto ambiental.</p>
            </div>
        </section>
        
        <div class="text2">
            <h2>O Que é o Armazenamento Gravitacional de Energia? </h2>
            <img src="" alt="">

            <p>O armazenamento gravitacional de energia é um método de armazenamento de energia que converte energia elétrica em energia potencial gravitacional. O princípio básico desse processo é simples: quando a energia elétrica está disponível em excesso, ela é usada para levantar um objeto pesado a uma altura específica, armazenando a energia potencial. Quando a demanda por energia é alta, o objeto é liberado para descer, e sua energia potencial é transformada novamente em energia elétrica por meio de um gerador. 
            <br>
            Esse tipo de tecnologia pode ser considerado uma forma de armazenamento mecânico de energia, similar ao que ocorre em barragens hidrelétricas, mas sem a necessidade de grandes reservatórios de água. Em vez disso, o foco está no movimento vertical de massas pesadas. </p>
            
            <h3 style="color:#006400;">Como Funciona o Sistema? </h3><br>

            <p>O conceito básico de um sistema de armazenamento gravitacional pode ser resumido em três etapas principais: 
            Armazenamento de Energia (Levantamento): Em momentos de baixa demanda, ou quando há uma sobrecarga de energia renovável (por exemplo, em um dia muito ensolarado ou ventoso), a energia elétrica é usada para levantar grandes massas. Isso é feito com o auxílio de um sistema de cabos e guinchos, onde a energia elétrica é convertida em trabalho mecânico para elevar a massa a uma grande altura. 
            <br>
            Armazenamento de Energia Potencial: Quando o objeto está elevado, a energia que foi usada para levá-lo a essa posição fica armazenada na forma de energia potencial gravitacional. Quanto maior a massa e maior a altura, maior será a quantidade de energia armazenada. 
            Liberação de Energia (Queda e Geração): Quando a demanda por energia aumenta, a massa é liberada e começa a descer devido à força da gravidade. O movimento descendente da massa é utilizado para gerar eletricidade. À medida que a massa cai, ela faz um gerador girar, convertendo a energia potencial novamente em energia elétrica. 
            Esse processo pode ser repetido várias vezes, tornando o sistema altamente durável e de longa duração.</p>
            <br>
            <h3 style="color:#006400;">Vantagens do Armazenamento Gravitacional de Energia </h3><br>
            <p><span class="artigo"><b>Escalabilidade</b></span>: O armazenamento gravitacional pode ser escalado de acordo com as necessidades de energia. Desde sistemas pequenos que atendem a necessidades locais até instalações massivas capazes de armazenar grandes quantidades de energia, a tecnologia é flexível e pode ser adaptada para diferentes contextos.</p>
            <p><span class="artigo"><b>Baixo Impacto Ambiental</b></span>: Diferente das baterias químicas, que dependem de metais raros e podem causar impactos ambientais ao longo de seu ciclo de vida, os sistemas gravitacionais geralmente usam materiais mais abundantes e acessíveis. Além disso, como não envolvem reações químicas complexas, eles não produzem poluição ou resíduos tóxicos durante o processo de armazenamento ou liberação de energia.</p>
            <p><span class="artigo"><b>Durabilidade e Baixa Manutenção</b></span>: Baterias convencionais, como as de íons de lítio, tendem a perder eficiência com o tempo e exigem substituições periódicas. Já os sistemas gravitacionais têm um desgaste muito menor, uma vez que a tecnologia se baseia principalmente em mecânica simples, o que resulta em uma vida útil muito mais longa e menos necessidade de manutenção.</p>
            <p><span class="artigo"><b>Armazenamento de Longo Prazo</b></span>: Enquanto as baterias de íons de lítio são mais adequadas para armazenar energia por períodos curtos (geralmente algumas horas), os sistemas gravitacionais podem ser mais eficazes no

            <h3 style="color:#006400;">Desafios e Limitações </h3><br>
            <p><span class="artigo"><b>Eficiência</b></span>:Embora os sistemas gravitacionais possam ter uma eficiência relativamente alta, ela não é perfeita. Parte da energia é sempre perdida durante o processo de levantamento e queda devido a atritos e outras perdas mecânicas. Contudo, empresas que desenvolvem essa tecnologia estão trabalhando para melhorar a eficiência de conversão energética. </p>
            <p><span class="artigo"><b>Espaço e Localização</b></span>: O armazenamento gravitacional depende da altura para armazenar energia. Isso significa que a instalação de sistemas grandes requer terrenos elevados ou a construção de estruturas verticais que podem ser caras e difíceis de implementar em certas regiões. No entanto, isso pode ser mitigado em áreas montanhosas ou próximas a infraestruturas já existentes. </p>
            <p><span class="artigo"><b>Custo Inicial </b></span>: Os custos iniciais para a construção de instalações de armazenamento gravitacional podem ser relativamente altos, especialmente em grande escala. Contudo, a tendência é que os custos diminuam à medida que a tecnologia se desenvolve e se torna mais comum. </p>
        </div><br>

        <div class="text2">
            <h2>Exemplos de Implementações Reais</h2>
            <p><span class="centralizando">O conceito de armazenamento gravitacional já começou a ser testado em projetos-piloto e comerciais em diferentes partes do mundo:</span></p>
            <p><span class="artigo"><b>Energy Vault</b></span>:Esta empresa suíça desenvolveu um sistema de armazenamento gravitacional utilizando enormes blocos de concreto empilhados em torres verticais. Quando a energia precisa ser liberada, os blocos são "desempilhados" e descem com geradores acoplados para gerar eletricidade. Este sistema já foi testado com sucesso e promete ser uma alternativa viável para o armazenamento de energia em larga escala.
            <p><span class="artigo">Gravitricity</b></span>: Em Edimburgo, na Escócia, a Gravitricity está desenvolvendo um sistema que utiliza cabos e massas pesadas para armazenar e liberar energia. Eles estão focados em construir uma instalação de 250 MW que poderia oferecer uma solução robusta para o armazenamento de energia renovável.
        </div>

        <div class="text2">
            <h2>O Futuro do Armazenamento Gravitacional</h2>
            <p>O armazenamento gravitacional está longe de ser a solução definitiva para todos os problemas de armazenamento de energia, mas oferece uma alternativa robusta, escalável e ambientalmente amigável às tecnologias convencionais. À medida que mais pesquisas são realizadas e mais investimentos são feitos, espera-se que essa tecnologia continue a evoluir, ganhando maior eficiência e viabilidade econômica.</p>
            <p>O avanço dessa tecnologia pode ser crucial para o futuro das energias renováveis, proporcionando uma maneira eficaz de gerenciar a produção intermitente de eletricidade e garantindo um fornecimento mais estável e sustentável de energia para o mundo.</p>
        </div>

        <div class="text2">
            <h2>Conclusão</h2>
            <p>O armazenamento gravitacional de energia apresenta-se como uma solução inovadora e promissora no cenário do armazenamento de energia renovável, especialmente em face das limitações de fontes como solar e eólica, que são intermitentes. Ao converter energia elétrica em energia potencial gravitacional, esse sistema oferece uma alternativa sustentável, com baixo impacto ambiental e alta durabilidade em comparação com baterias químicas tradicionais.
            <br>
            Embora enfrente desafios como custos iniciais elevados e necessidade de locais adequados para implementação, suas vantagens, como escalabilidade, longa vida útil e ausência de resíduos tóxicos, tornam essa tecnologia uma candidata importante para complementar o portfólio de soluções energéticas do futuro. Projetos como os da Energy Vault e da Gravitricity demonstram que o armazenamento gravitacional está deixando de ser apenas uma ideia para se tornar uma realidade prática e economicamente viável.
            <br>
            Em um mundo em transição para uma matriz energética mais limpa, tecnologias como o armazenamento gravitacional desempenharão um papel essencial no gerenciamento eficiente da energia renovável, contribuindo para um futuro mais sustentável e estável.</p>            
        </div>
    </div>
    
    <section class="comentario_artigo">
        <div class="centralizando">
            <h2 class="text2">Deixe seu comentário</h2>
            <br>
                <form method="POST" action="../../controllers/controlador_comentarios.php">
                <textarea name="comentario" placeholder="Digite seu comentário aqui"></textarea><br>                <button type="submit" name="botao_comentario">Enviar Comentário</button>
            </form>

            <p class="centralizando"><?php echo isset($_GET['comentarioEnviado']) ? $_GET['comentarioEnviado'] : ''; ?></p>
            
            <p class="centralizando" style="color: red;"><?php echo isset($_GET['erroMensagem']) ? $_GET['erroMensagem'] : ''; ?></p>

            <h3>Comentários</h3>
            <?php

                include("../../config/conexaoBD.php");
                        
                $sql = "SELECT Cadastro.Nome, Comentarios.comentario, Comentarios.data 
                FROM Comentarios 
                INNER JOIN Cadastro ON Comentarios.IdCadastro = Cadastro.IdCadastro 
                ORDER BY Comentarios.data DESC";

                $result = $conexao->query($sql);
                        
                if ($result && $result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                    echo '<div class="comentario">';
                    echo '<strong>' . htmlspecialchars($row['Nome']) . '</strong>';
                    echo '<p>' . htmlspecialchars($row['comentario']) . '</p>';
                    echo '<p><i>' . date('d/m/Y H:i', strtotime($row['data'])) . '</i></p>';
                    echo '</div>';
                    }
                } else {
                        echo '<p>Nenhum comentário encontrado.</p>';
                        }
            ?>
            </div>
        </section>
</body>
</html>